package net.runelite.client.plugins.microbot.templetrekking;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.*;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.widgets.Widget;
import net.runelite.client.plugins.microbot.Microbot;
import net.runelite.client.plugins.microbot.Script;
import net.runelite.client.plugins.microbot.util.dialogues.Rs2Dialogue;
import net.runelite.client.plugins.microbot.api.npc.Rs2NpcCache;
import net.runelite.client.plugins.microbot.api.npc.models.Rs2NpcModel;
import net.runelite.client.plugins.microbot.api.tileobject.Rs2TileObjectCache;
import net.runelite.client.plugins.microbot.api.tileobject.models.Rs2TileObjectModel;
import net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory;
import net.runelite.client.plugins.microbot.util.player.Rs2Player;
import net.runelite.client.plugins.microbot.util.walker.Rs2Walker;
import net.runelite.client.plugins.microbot.util.widget.Rs2Widget;

import javax.inject.Inject;
import java.util.concurrent.TimeUnit;

@Slf4j
public class TempleTrekkingScript extends Script {

    // -------------------------------------------------------------------------
    // NPC / Object / Widget IDs
    // -------------------------------------------------------------------------

    // Escort NPCs
    private static final String ESCORT_PATERDOMUS   = "Rolayne Twickit";   // at Paterdomus end
    private static final String ESCORT_BURGH         = "Rolayne Twickit";   // same NPC, Burgh end

    // Follower NPC name (the person we escort)
    private static final String FOLLOWER_NAME        = "Adventurer";

    // Route selection widget (group underground passage route select)
    private static final int WIDGET_ROUTE_GROUP      = 270;
    private static final int WIDGET_ROUTE_EASY       = 1;   // child index for easy route
    private static final int WIDGET_ROUTE_MED        = 2;
    private static final int WIDGET_ROUTE_HARD       = 3;

    // Reward interface
    private static final int WIDGET_REWARD_GROUP     = 274;
    private static final int WIDGET_REWARD_DISMISS   = 2;   // "Dismiss" – skip reward
    private static final int WIDGET_REWARD_TOKEN     = 8;   // reward token child
    private static final int WIDGET_REWARD_TOME      = 9;   // XP tome child

    // Item IDs
    private static final int ITEM_REWARD_TOKEN       = 2996;
    private static final int ITEM_TOME_EXPERIENCE    = 2997;

    // Key object IDs
    private static final int OBJ_DEAD_TREE           = 1365;   // signals zombie/lumberjack bridge event
    private static final int OBJ_BRIDGE_PLANK        = 10803;  // planks on the ground
    private static final int OBJ_BRIDGE_REPAIR       = 10804;  // repairable bridge section
    private static final int OBJ_VINE                = 10730;  // vine to cut for river crossing
    private static final int OBJ_SWING_ROPE          = 10729;  // rope to swing across

    // Axe item check (any axe)
    private static final int[] AXE_IDS = {
        ItemID.BRONZE_AXE, ItemID.IRON_AXE, ItemID.STEEL_AXE,
        ItemID.BLACK_AXE, ItemID.MITHRIL_AXE, ItemID.ADAMANT_AXE,
        ItemID.RUNE_AXE, ItemID.DRAGON_AXE, ItemID.INFERNAL_AXE,
        ItemID._3RD_AGE_AXE, ItemID.CRYSTAL_AXE, ItemID.GILDED_AXE
    };

    // Inventory free-slot threshold with a small random buffer
    private static final int RANDOM_SLOT_BUFFER = 1;

    // -------------------------------------------------------------------------
    // Injected caches (Queryable API)
    // -------------------------------------------------------------------------

    @Inject
    private Rs2NpcCache npcCache;

    @Inject
    private Rs2TileObjectCache tileObjectCache;

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    @Getter
    private TempleTrekkingState state = TempleTrekkingState.IDLE;

    private TempleTrekkingConfig config;

    // -------------------------------------------------------------------------
    // Entry point
    // -------------------------------------------------------------------------

    public boolean run(TempleTrekkingConfig config) {
        this.config = config;
        state = TempleTrekkingState.IDLE;

        mainScheduledFuture = scheduledExecutorService.scheduleWithFixedDelay(() -> {
            try {
                if (!Microbot.isLoggedIn()) return;
                if (!super.run()) return;

                tick();

            } catch (Exception ex) {
                Microbot.logStackTrace(this.getClass().getSimpleName(), ex);
            }
        }, 0, 600, TimeUnit.MILLISECONDS);

        return true;
    }

    // -------------------------------------------------------------------------
    // Main tick dispatcher
    // -------------------------------------------------------------------------

    private void tick() {
        // Always handle dialogue first — it blocks everything else
        if (Rs2Dialogue.isInDialogue()) {
            handleDialogue();
            return;
        }

        // Reward interface open?
        if (isRewardInterfaceOpen()) {
            handleReward();
            return;
        }

        switch (state) {
            case IDLE:
                state = TempleTrekkingState.START_TREK;
                break;

            case START_TREK:
                handleStartTrek();
                break;

            case SELECT_ROUTE:
                handleSelectRoute();
                break;

            case TREKKING:
                handleTrekking();
                break;

            case DETECT_EVENT:
                detectEvent();
                break;

            case BRIDGE_CHOP_TREES:
                handleBridgeChopTrees();
                break;

            case BRIDGE_KILL_ZOMBIES:
                handleBridgeKillZombies();
                break;

            case RIVER_CROSSING:
                handleRiverCrossing();
                break;

            case CONTINUE_TREK:
                handleContinueTrek();
                break;

            case TREK_COMPLETE:
                handleTrekComplete();
                break;

            case CHECK_INVENTORY:
                handleCheckInventory();
                break;

            case BANKING:
                handleBanking();
                break;

            case REDEEM_TOKENS:
                handleRedeemTokens();
                break;

            case USE_TOMES:
                handleUseTomes();
                break;

            case EVADE_COMBAT:
                handleEvadeCombat();
                break;

            case UNKNOWN_EVENT:
                // Don't know what's happening — just keep walking
                state = TempleTrekkingState.TREKKING;
                break;
        }
    }

    // -------------------------------------------------------------------------
    // State handlers
    // -------------------------------------------------------------------------

    private void handleStartTrek() {
        // Find the escort NPC and talk to them to start a trek
        String npcName = config.trekDirection() == TempleTrekkingConfig.TrekDirection.BURGH_DE_ROTT_RAMBLE
                ? ESCORT_PATERDOMUS
                : ESCORT_BURGH;

        Rs2NpcModel escort = npcCache.query()
                .withName(npcName)
                .nearest();
        if (escort == null) {
            log.warn("Cannot find escort NPC '{}'. Waiting...", npcName);
            return;
        }

        escort.click("Start-trek");
        sleepUntil(Rs2Dialogue::isInDialogue, 5000);
        state = TempleTrekkingState.SELECT_ROUTE;
    }

    private void handleSelectRoute() {
        // Route selection widget should be open
        Widget routeWidget = Rs2Widget.getWidget(WIDGET_ROUTE_GROUP, WIDGET_ROUTE_EASY);
        if (routeWidget == null) {
            // Maybe dialogue is still open — let the dialogue handler deal with it
            if (!Rs2Dialogue.isInDialogue()) {
                // No widget, no dialogue — something went wrong, retry
                state = TempleTrekkingState.START_TREK;
            }
            return;
        }

        // Always pick easy route for maximum speed
        Rs2Widget.clickWidget(WIDGET_ROUTE_GROUP, WIDGET_ROUTE_EASY);
        sleepUntil(() -> Rs2Widget.getWidget(WIDGET_ROUTE_GROUP, WIDGET_ROUTE_EASY) == null, 5000);
        state = TempleTrekkingState.TREKKING;
    }

    private void handleTrekking() {
        // Check for events first
        if (isEventPresent()) {
            state = TempleTrekkingState.DETECT_EVENT;
            return;
        }

        // Check if we've reached the destination
        if (isAtDestination()) {
            state = TempleTrekkingState.TREK_COMPLETE;
            return;
        }

        // Keep following / walking with the follower
        Rs2NpcModel follower = npcCache.query()
                .withName(FOLLOWER_NAME)
                .nearest();
        if (follower != null) {
            WorldPoint followerLoc = follower.getWorldLocation();
            if (Rs2Player.distanceTo(followerLoc) > 3) {
                Rs2Walker.walkTo(followerLoc);
            }
        }
    }

    private void detectEvent() {
        // Determine which event type is active by checking for specific objects

        // Dead tree = zombie/lumberjack bridge event
        boolean hasDeadTree = tileObjectCache.query().withId(OBJ_DEAD_TREE).nearest() != null;

        // Bridge repair sections = tree bridge event (no dead tree present)
        boolean hasBridgeRepair = tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest() != null;

        // Vine = river crossing
        boolean hasVine = tileObjectCache.query().withId(OBJ_VINE).nearest() != null;

        if (hasDeadTree && config.doBridgeLumberjacks()) {
            state = TempleTrekkingState.BRIDGE_KILL_ZOMBIES;
        } else if (hasBridgeRepair && !hasDeadTree && config.doBridgeTrees()) {
            state = TempleTrekkingState.BRIDGE_CHOP_TREES;
        } else if (hasVine && config.doRiverCrossing()) {
            state = TempleTrekkingState.RIVER_CROSSING;
        } else {
            // No recognised event or user disabled this event type — skip it
            state = TempleTrekkingState.CONTINUE_TREK;
        }
    }

    private void handleBridgeChopTrees() {
        // Find a tree to chop — look for any object with a "Chop" action
        Rs2TileObjectModel tree = tileObjectCache.query()
                .where(obj -> {
                    ObjectComposition comp = obj.getObjectComposition();
                    if (comp == null) return false;
                    String[] actions = comp.getImpostorIds() != null && comp.getImpostor() != null
                            ? comp.getImpostor().getActions()
                            : comp.getActions();
                    if (actions == null) return false;
                    for (String a : actions) {
                        if ("Chop".equalsIgnoreCase(a)) return true;
                    }
                    return false;
                })
                .nearest();

        if (tree != null) {
            tree.click("Chop");
            Rs2Player.waitForXpDrop(Skill.WOODCUTTING, 8000);
            sleep(400, 800);
            return;
        }

        // Use planks on bridge repair section
        if (Rs2Inventory.hasItem(ItemID.PLANK)) {
            Rs2TileObjectModel bridge = tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest();
            if (bridge != null) {
                Rs2Inventory.useItemOnObject(ItemID.PLANK, bridge.getId());
                sleepUntil(() -> tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest() == null, 10000);
                sleep(300, 700);
                return;
            }
        }

        // Event complete — continue trek
        if (tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest() == null) {
            state = TempleTrekkingState.CONTINUE_TREK;
        }
    }

    private void handleBridgeKillZombies() {
        // Attack undead lumberjacks — find any NPC with an "Attack" action
        Rs2NpcModel lumberjack = npcCache.query()
                .where(npc -> {
                    NPCComposition comp = Microbot.getClientThread()
                            .runOnClientThreadOptional(() -> Microbot.getClient().getNpcDefinition(npc.getId()))
                            .orElse(null);
                    if (comp == null) return false;
                    String[] actions = comp.getActions();
                    if (actions == null) return false;
                    for (String a : actions) {
                        if ("Attack".equalsIgnoreCase(a)) return true;
                    }
                    return false;
                })
                .nearest();

        if (lumberjack != null) {
            lumberjack.click("Attack");
            sleepUntil(() -> !Rs2Player.isAnimating(), 8000);
            sleep(300, 600);
            return;
        }

        // All killed — use planks on bridge
        if (Rs2Inventory.hasItem(ItemID.PLANK)) {
            Rs2TileObjectModel bridge = tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest();
            if (bridge != null) {
                Rs2Inventory.useItemOnObject(ItemID.PLANK, bridge.getId());
                sleepUntil(() -> tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest() == null, 10000);
                sleep(300, 700);
                return;
            }
        }

        if (tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest() == null) {
            state = TempleTrekkingState.CONTINUE_TREK;
        }
    }

    private void handleRiverCrossing() {
        // Cut vine first
        Rs2TileObjectModel vine = tileObjectCache.query().withId(OBJ_VINE).nearest();
        if (vine != null) {
            vine.click("Cut");
            sleepUntil(() -> tileObjectCache.query().withId(OBJ_VINE).nearest() == null, 8000);
            sleep(400, 800);
            return;
        }

        // Swing rope
        Rs2TileObjectModel rope = tileObjectCache.query().withId(OBJ_SWING_ROPE).nearest();
        if (rope != null) {
            rope.click("Swing-on");
            sleepUntil(Rs2Player::isAnimating, 5000);
            sleepUntil(() -> !Rs2Player.isAnimating(), 8000);
            sleep(300, 700);
            state = TempleTrekkingState.CONTINUE_TREK;
        }
    }

    private void handleContinueTrek() {
        // Click through any remaining dialogue to continue the trek
        if (Rs2Dialogue.isInDialogue()) {
            Rs2Dialogue.clickContinue();
            sleep(400, 800);
        } else {
            state = TempleTrekkingState.TREKKING;
        }
    }

    private void handleTrekComplete() {
        // Reward interface will open automatically; the tick loop handles it.
        // Transition to inventory check after reward is handled.
        state = TempleTrekkingState.CHECK_INVENTORY;
    }

    private void handleCheckInventory() {
        int freeSlots = Rs2Inventory.getEmptySlots();
        int threshold = config.minFreeSlots() + (Math.random() < 0.5 ? 0 : RANDOM_SLOT_BUFFER);

        if (freeSlots > threshold) {
            // Plenty of space — start next trek immediately
            state = TempleTrekkingState.START_TREK;
            return;
        }

        switch (config.inventoryManagement()) {
            case BANK:
                state = TempleTrekkingState.BANKING;
                break;
            case REDEEM_TOMES:
                state = TempleTrekkingState.REDEEM_TOKENS;
                break;
            case NONE:
            default:
                // Just keep going regardless
                state = TempleTrekkingState.START_TREK;
                break;
        }
    }

    private void handleBanking() {
        // Walk to Burgh de Rott bank and deposit reward tokens
        WorldPoint burghBank = new WorldPoint(3494, 3215, 0);
        if (Rs2Player.distanceTo(burghBank) > 5) {
            Rs2Walker.walkTo(burghBank);
            sleepUntil(() -> Rs2Player.distanceTo(burghBank) < 5, 30000);
            return;
        }

        if (net.runelite.client.plugins.microbot.util.bank.Rs2Bank.openBank()) {
            sleepUntil(() -> net.runelite.client.plugins.microbot.util.bank.Rs2Bank.isOpen(), 5000);
            net.runelite.client.plugins.microbot.util.bank.Rs2Bank.depositAll();
            sleep(600, 1200);
            net.runelite.client.plugins.microbot.util.bank.Rs2Bank.closeBank();
            sleep(400, 800);
        }

        state = TempleTrekkingState.START_TREK;
    }

    private void handleRedeemTokens() {
        if (!Rs2Inventory.hasItem(ITEM_REWARD_TOKEN)) {
            state = TempleTrekkingState.USE_TOMES;
            return;
        }

        // Open reward token interface — interact with the token item
        Rs2Inventory.interact(ITEM_REWARD_TOKEN, "Use");
        sleepUntil(() -> isRewardInterfaceOpen(), 5000);

        if (isRewardInterfaceOpen()) {
            // Click the XP tome option (child index 9)
            Rs2Widget.clickWidget(WIDGET_REWARD_GROUP, WIDGET_REWARD_TOME);
            sleepUntil(() -> !isRewardInterfaceOpen(), 5000);
            sleep(300, 600);
        }
    }

    private void handleUseTomes() {
        if (!Rs2Inventory.hasItem(ITEM_TOME_EXPERIENCE)) {
            state = TempleTrekkingState.START_TREK;
            return;
        }

        Rs2Inventory.interact(ITEM_TOME_EXPERIENCE, "Read");
        sleepUntil(() -> !Rs2Inventory.hasItem(ITEM_TOME_EXPERIENCE), 5000);
        sleep(300, 700);
    }

    private void handleEvadeCombat() {
        // Walk away from attackers
        WorldPoint safeSpot = Rs2Player.getWorldLocation().dx(5);
        Rs2Walker.walkTo(safeSpot);
        sleepUntil(() -> !Rs2Player.isAnimating(), 5000);
        state = TempleTrekkingState.TREKKING;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void handleDialogue() {
        if (Rs2Dialogue.hasSelectAnOption()) {
            // Route selection is handled in SELECT_ROUTE; just click continue otherwise
            Rs2Dialogue.clickContinue();
        } else {
            Rs2Dialogue.clickContinue();
        }
        sleep(300, 600);
    }

    private void handleReward() {
        // Dismiss the reward interface (take nothing — we want the token in inventory)
        Rs2Widget.clickWidget(WIDGET_REWARD_GROUP, WIDGET_REWARD_DISMISS);
        sleepUntil(() -> !isRewardInterfaceOpen(), 5000);
        sleep(300, 600);
    }

    private boolean isRewardInterfaceOpen() {
        Widget w = Rs2Widget.getWidget(WIDGET_REWARD_GROUP, 0);
        return w != null && !w.isHidden();
    }

    private boolean isEventPresent() {
        return tileObjectCache.query().withId(OBJ_DEAD_TREE).nearest() != null
            || tileObjectCache.query().withId(OBJ_BRIDGE_REPAIR).nearest() != null
            || tileObjectCache.query().withId(OBJ_VINE).nearest() != null;
    }

    private boolean isAtDestination() {
        // At Burgh de Rott end  (~3494, 3215) or Paterdomus end (~3403, 3481)
        WorldPoint pos = Rs2Player.getWorldLocation();
        if (config.trekDirection() == TempleTrekkingConfig.TrekDirection.BURGH_DE_ROTT_RAMBLE) {
            return pos.distanceTo(new WorldPoint(3494, 3215, 0)) < 20;
        } else {
            return pos.distanceTo(new WorldPoint(3403, 3481, 0)) < 20;
        }
    }

    @Override
    public void shutdown() {
        super.shutdown();
        state = TempleTrekkingState.IDLE;
    }
}
