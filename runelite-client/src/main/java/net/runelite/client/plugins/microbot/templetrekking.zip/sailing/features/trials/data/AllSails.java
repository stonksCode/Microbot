package net.runelite.client.plugins.microbot.sailing.features.trials.data;

import net.runelite.api.gameval.ObjectID;

import java.util.List;

public class AllSails {
    public static final List<Integer> GAMEOBJECT_IDS = List.of(
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_1X3_WOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_2X5_WOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_WOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_1X3_OAK,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_2X5_OAK,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_OAK,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_1X3_TEAK,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_2X5_TEAK,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_TEAK,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_MAHOGANY,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_MAHOGANY,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_MAHOGANY,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_1X3_CAMPHOR,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_2X5_CAMPHOR,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_CAMPHOR,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_1X3_IRONWOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_2X5_IRONWOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_IRONWOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_1X3_ROSEWOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_2X5_ROSEWOOD,
            ObjectID.SAILING_BOAT_SAIL_KANDARIN_3X8_ROSEWOOD);
}
