package net.runelite.client.plugins.microbot.templetrekking;

import com.google.inject.Provides;
import lombok.extern.slf4j.Slf4j;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.overlay.OverlayManager;

import javax.inject.Inject;

@PluginDescriptor(
        name = PluginDescriptor.Default + "Temple Trekking",
        description = "Automates the Temple Trekking / Burgh de Rott Ramble minigame",
        tags = {"temple", "trekking", "burgh de rott", "minigame", "morytania"},
        enabledByDefault = false
)
@Slf4j
public class TempleTrekkingPlugin extends Plugin {

    @Inject
    private TempleTrekkingConfig config;

    @Inject
    private TempleTrekkingScript script;

    @Inject
    private OverlayManager overlayManager;

    @Inject
    private TempleTrekkingOverlay overlay;

    @Provides
    TempleTrekkingConfig provideConfig(ConfigManager configManager) {
        return configManager.getConfig(TempleTrekkingConfig.class);
    }

    @Override
    protected void startUp() {
        overlayManager.add(overlay);
        script.run(config);
    }

    @Override
    protected void shutDown() {
        script.shutdown();
        overlayManager.remove(overlay);
    }
}
