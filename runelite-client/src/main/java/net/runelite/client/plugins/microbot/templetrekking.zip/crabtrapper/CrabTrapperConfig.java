package net.runelite.client.plugins.microbot.crabtrapper;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;

@ConfigGroup("CrabTrapper")
public interface CrabTrapperConfig extends Config {

    @ConfigItem(
            keyName = "crabType",
            name = "Crab Type",
            description = "Which crab to trap. More types will be added as Blue and Rainbow crabs are supported.",
            position = 0
    )
    default CrabTrapperScript.CrabType crabType() {
        return CrabTrapperScript.CrabType.RED_CRAB;
    }

    @ConfigItem(
            keyName = "inventoryMode",
            name = "Inventory Mode",
            description = "What to do when your inventory fills with crabs. PASTE: crush with pestle+mortar. CUT: cut with knife and bank meat. BANK: bank crabs directly. DROP: drop all crabs on the ground.",
            position = 1
    )
    default CrabTrapperScript.InventoryMode inventoryMode() {
        return CrabTrapperScript.InventoryMode.PASTE;
    }

    @ConfigItem(
            keyName = "timingMode",
            name = "Timing Mode",
            description = "RELAXED: waits the 3-tick auto-rebait window before collecting. IMMEDIATE: collects as soon as a trap is full. RANDOM: alternates between the two to appear more human.",
            position = 2
    )
    default CrabTrapperScript.TimingMode timingMode() {
        return CrabTrapperScript.TimingMode.RANDOM;
    }

    @ConfigItem(
            keyName = "useCustomTrapLocations",
            name = "Use Custom Trap Locations",
            description = "When enabled, the script uses the coordinates you enter below instead of the built-in hardcoded locations. "
                    + "Applies to Blue Crab mode. Red Crab mode always uses its own hardcoded spots.",
            position = 3
    )
    default boolean useCustomTrapLocations() {
        return false;
    }

    @ConfigItem(
            keyName = "customTrapLocations",
            name = "Custom Trap Locations",
            description = "Comma-separated list of X Y tile coordinates for your trap spots, e.g. \"3250 2432, 3253 2431, 3250 2430\". "
                    + "Only used when 'Use Custom Trap Locations' is enabled. Up to 5 spots supported.",
            position = 4
    )
    default String customTrapLocations() {
        return "3250 2432, 3253 2431, 3250 2430";
    }
}
